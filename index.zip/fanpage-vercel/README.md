# Página de confirmação de idade

Landing page estática, responsiva, em preto e vermelho, pronta para publicar na Vercel.

## Antes de publicar
1. Abra `index.html`.
2. Encontre `const DESTINATION_URL = "https://example.com";`.
3. Troque `https://example.com` pelo endereço completo do site de destino.
4. Salve o arquivo.

## Publicar na Vercel
1. Entre em https://vercel.com/ e faça login.
2. Crie um repositório GitHub com os arquivos desta pasta ou importe um repositório existente.
3. Na Vercel, selecione **Add New → Project** e importe o repositório.
4. Como é um site estático simples, não precisa de comando de build nem diretório de saída especial.
5. Clique em **Deploy** e teste o endereço gerado no celular.

O botão só redireciona depois que você configurar o destino. A página de confirmação de idade, por si só, não verifica a idade real do visitante.
